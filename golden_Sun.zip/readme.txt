Golden Sun Randomizer Tracer 

How to use

1. Download zip file
2. Place into C:\Users\[Your Username]\Documents\EmoTracker\packs
3. Open EmoTracker
4. Installed Packages>Other


For any Tracker Problems contact the creator on twitter. 
Twitter.com/DerrickGnC

Randomizer Created by 
"Marvin" on goldensunhacking forums
http://forum.goldensunhacking.net/index.php?action=downloads;sa=view;down=120
